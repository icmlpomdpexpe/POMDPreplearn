import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
observations=10
def porl2_decodable(representation_classes, K, alpha_k, lambda_k, H, Zcal, Acal, collect_data, learn_representation, reward_func):
    policies = []
    D = [set() for _ in range(H)]
    D_prime = [set() for _ in range(H)]

    for k in range(K):
        # Data collection
        for h in range(H):
            tau_h, tau_h_prime = collect_data(h, policies[-1] if policies else None)
            D[h].add(tau_h)
            D_prime[h].add(tau_h_prime)

        # Learn representations
        
        representation_learner = RepresentationLearner(num_phi_models=len(representation_classes), num_mu_models=len(representation_classes), z_dim=Zcal, action_dim=Acal, device=device)
        phi_hat, mu_hat = learn_representation(D, D_prime, representation_learner)

        # Define exploration bonus
        b_hat = []
        for h in range(H):
            Sigma_h = sum([np.outer(phi_hat[h](z, a), phi_hat[h](z, a)) for z, a in D[h]]) + lambda_k * np.eye(phi_hat[h].shape[1])
            b_hat.append(lambda z, a: min(alpha_k * np.sqrt(phi_hat[h](z, a).T @ np.linalg.inv(Sigma_h) @ phi_hat[h](z, a)), 2))

        # LSVI-LLR
        new_policy = lsvi_llr(reward_func, b_hat, phi_hat, mu_hat, D, D_prime, lambda_k, H, Zcal, Acal)
        policies.append(new_policy)

    return policies

def lsvi_llr(reward_func, b_hat, phi_hat, mu_hat, D, D_prime, lambda_k, H, Zcal, Acal):
    V = [np.zeros(len(Zcal)) for _ in range(H + 1)]
    pi = [None for _ in range(H)]

    for h in range(H - 1, 0, -1):
        Q = np.zeros((len(Zcal), len(Acal)))
        for z_idx, z in enumerate(Zcal):
            for a_idx, a in enumerate(Acal):
                Q[z_idx, a_idx] = reward_func[h](z, a) + b_hat[h](z, a) + sum([phi_hat[h](z, a).T @ mu_hat[h](o) * V[h + 1](Zcal.index(c(z, a, o))) for o in D[h]])
        V[h] = np.max(Q, axis=1)
        pi[h] = np.argmax(Q, axis=1)

    return pi

def collect_data(h, last_policy):
    if h < 0:
        return None, None
    
    if last_policy is None:
        agent_pi_h = lambda _: np.random.choice(Acal)
        agent_pi_h_prime = lambda _: np.random.choice(Acal)
    else:
        def agent_pi_h(step):
            if step < h - 2:
                return last_policy[step]
            return np.random.choice(Acal)

        def agent_pi_h_prime(step):
            if step < h - 4:
                return last_policy[step]
            return np.random.choice(Acal)

    tau_h = []
    tau_h_prime = []

    state = env.reset()
    done = False
    while not done:
        action = agent_pi_h(len(tau_h))
        next_state, reward, done, _ = env.step(action)
        tau_h.append((state, action, next_state, reward))
        state = next_state

    state = env.reset()
    done = False
    while not done:
        action = agent_pi_h_prime(len(tau_h_prime))
        next_state, reward, done, _ = env.step(action)
        tau_h_prime.append((state, action, next_state, reward))
        state = next_state

    return tau_h, tau_h_prime



class YourNeuralNetworkModel(nn.Module):
    def __init__(self, z_dim, action_dim, device, state_dim=3, tau=1, softmax="vanilla"):
        super(YourNeuralNetworkModel, self).__init__()

        self.feature = Feature(z_dim, action_dim, device, state_dim=state_dim, tau=tau, softmax=softmax)
        
    def forward(self, z, action):
        return self.feature(z, action)

class Feature(nn.Module):
    def __init__(self, z_dim, action_dim, device, state_dim=3, tau=1, softmax="vanilla"):
        super().__init__()

        self.device = device
        self.z_dim = z_dim
        self.action_dim = action_dim
        self.state_dim = state_dim

        self.tau = tau
        self.softmax = softmax

        self.encoder = nn.Linear(z_dim, state_dim, bias=False)
        self.weights = nn.Linear(state_dim * action_dim, 1, bias=False)

        self.apply(weight_init)

    def forward(self, z, action):
        assert z.size(0) == action.size(0)
        state_encoding = self.encoder(z)
        if self.softmax == "gumble":
            state_encoding = F.gumbel_softmax(state_encoding, tau=self.tau, hard=False)
        elif self.softmax == 'vanilla': 
            state_encoding = F.softmax(state_encoding / self.tau, dim=-1)
        phi = kron(action, state_encoding)

        return phi

def weight_init(m):
    if isinstance(m, nn.Linear):
        nn.init.orthogonal_(m.weight.data)
        if m.bias is not None:
            m.bias.data.fill_(0.0)
    elif isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
        m.weight.data.fill_(0.0)
        m.bias.data.fill_(0.0)
        mid = m.weight.size(2) // 2
        gain = nn.init.calculate_gain('relu')
        nn.init.orthogonal_(m.weight.data[:, :, mid, mid], gain)

def kron(a, b):
    siz1 = torch.Size(torch.tensor(a.shape[-1:]) * torch.tensor(b.shape[-1:]))
    res = a.unsqueeze(-1) * b.unsqueeze(-2)
    siz0 = res.shape[:-2]
    return res.reshape(siz0 + siz1)
class YourNeuralNetworkModelmu(nn.Modulemu):
    def __init__(self, z_dim, action_dim, device, state_dim=3, tau=1, softmax="vanilla"):
        super(YourNeuralNetworkModelmu, self).__init__()

        self.feature = Feature(z_dim, action_dim, device, state_dim=state_dim, tau=tau, softmax=softmax)
        
    def forward(self, z, action):
        return self.feature(z, action)

class Feature(nn.Modulemu):
    def __init__(self, z_dim, action_dim, device, state_dim=3, tau=1, softmax="vanilla"):
        super().__init__()

        self.device = device
        self.z_dim = z_dim
        self.action_dim = action_dim
        self.state_dim = state_dim

        self.tau = tau
        self.softmax = softmax

        self.encoder = nn.Linear(z_dim, state_dim, bias=False)
        self.weights = nn.Linear(state_dim * action_dim, 1, bias=False)

        self.apply(weight_init)

    def forward(self, z, action):
        assert z.size(0) == action.size(0)
        state_encoding = self.encoder(z)
        if self.softmax == "gumble":
            state_encoding = F.gumbel_softmax(state_encoding, tau=self.tau, hard=False)
        elif self.softmax == 'vanilla': 
            state_encoding = F.softmax(state_encoding / self.tau, dim=-1)
        mu = kron(action, state_encoding) / observations

        return mu

    def weight_init(m):
        if isinstance(m, nn.Linear):
            nn.init.orthogonal_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)
        elif isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
            m.weight.data.fill_(0.0)
            m.bias.data.fill_(0.0)
            mid = m.weight.size(2) // 2
            gain = nn.init.calculate_gain('relu')
            nn.init.orthogonal_(m.weight.data[:, :, mid, mid], gain)

    def kron(a, b):
        siz1 = torch.Size(torch.tensor(a.shape[-1:]) * torch.tensor(b.shape[-1:]))
        res = a.unsqueeze(-1) * b.unsqueeze(-2)
        siz0 = res.shape[:-2]
        return res.reshape(siz0 + siz1)
class RepresentationLearner:
    def __init__(self, num_phi_models, num_mu_models, z_dim, action_dim, device, state_dim=3, tau=1, softmax="vanilla"):
        self.phi_models = [YourNeuralNetworkModel(z_dim, action_dim, device, state_dim, tau, softmax) for _ in range(num_phi_models)]
        self.mu_models = [YourNeuralNetworkModelmu(z_dim, action_dim, device, state_dim, tau, softmax) for _ in range(num_mu_models)]

        self.device = device

    def learn_representation(self, D, D_prime, epochs=100, lr=1e-3):
        optimizer_phi = [optim.Adam(phi.parameters(), lr=lr) for phi in self.phi_models]
        optimizer_mu = [optim.Adam(mu.parameters(), lr=lr) for mu in self.mu_models]

        # Combine D and D_prime into a single dataset
        combined_dataset = []
        for h in range(len(D)):
            combined_dataset.extend([(z_h, a_h, z) for z_h, a_h, z_next in zip(D[h], D_prime[h])])

        for epoch in range(epochs):
            avg_loss = 0
            for data in combined_dataset:
                z_h, a_h, z_next = data
                z_h = torch.tensor(z_h, dtype=torch.float32).to(self.device)
                a_h = torch.tensor(a_h, dtype=torch.float32).to(self.device)
                z_next = torch.tensor(z_next, dtype=torch.float32).to(self.device)

                max_expectation = -np.inf
                best_phi_idx, best_mu_idx = None, None

                for i, phi in enumerate(self.phi_models):
                    for j, mu in enumerate(self.mu_models):
                        phi_out = phi(z_h, a_h)
                        mu_out = mu(z_next, a_h)

                        expectation = torch.mean(torch.log(torch.matmul(phi_out, mu_out.t())))
                        if expectation > max_expectation:
                            max_expectation = expectation
                            best_phi_idx, best_mu_idx = i, j

                best_phi = self.phi_models[best_phi_idx]
                best_mu = self.mu_models[best_mu_idx]

                phi_loss = -torch.mean(torch.log(torch.matmul(best_phi(z_h, a_h), best_mu(z_next, a_h).t())))
                mu_loss = -torch.mean(torch.log(torch.matmul(best_phi(z_h, a_h), best_mu(z_next, a_h).t())))

                optimizer_phi[best_phi_idx].zero_grad()
                phi_loss.backward(retain_graph=True)
                optimizer_phi[best_phi_idx].step()

                optimizer_mu[best_mu_idx].zero_grad()
                mu_loss.backward()
                optimizer_mu[best_mu_idx].step()

                avg_loss += phi_loss.item() + mu_loss.item()

            avg_loss /= len(combined_dataset)
            print(f'Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.4f}')
