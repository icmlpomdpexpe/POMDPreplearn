import numpy as np
import itertools

# 定义已知集合A和B
A = [1, 2, 3]
B = [4, 5, 6]

# 生成A和B的所有可能的mu和phi组合
mu_phi_combinations = list(itertools.product(A, B))

# 定义函数来计算期望
def calc_expectation(mu, phi, D, D_prime):
    expectation = 0
    for z, a, o in zip(D['z'], D['a'], D_prime['o']):
        expectation += np.log(phi[z, a]) + np.dot(mu[z], o)
    for z, a, o in zip(D_prime['z'], D_prime['a'], D['o']):
        expectation += np.log(phi[z, a]) + np.dot(mu[z], o)
    return expectation

# 定义变量D和D_prime
D = {'z': [1, 2, 3], 'a': [4, 5, 6], 'o': [[1, 2], [2, 3], [3, 4]]}
D_prime = {'z': [2, 3, 1], 'a': [6, 4, 5], 'o': [[2, 3], [3, 4], [1, 2]]}

# 遍历mu和phi的所有组合，计算期望并取最大值
max_expectation = -np.inf
for mu, phi in mu_phi_combinations:
    expectation = calc_expectation(mu, phi, D, D_prime)
    if expectation > max_expectation:
        max_expectation = expectation
        best_mu = mu
        best_phi = phi