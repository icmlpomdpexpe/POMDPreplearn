import numpy as np
import gym
from gym.spaces import Discrete, Box
import scipy.linalg
import math
import numpy as np
import gym
from gym.spaces import Discrete, Box
import scipy.linalg
import math
import numpy as np
import gym
from gym.spaces import Discrete, Box
import scipy.linalg
import math
import numpy as np
import gym
from gym import spaces
'''
fast sampling. credit: https://stackoverflow.com/questions/34187130/fast-random-weighted-selection-across-all-rows-of-a-stochastic-matrix/34190035
'''
def sample(prob_matrix, items, n):

    cdf = np.cumsum(prob_matrix, axis=1)
    # random numbers are expensive, so we'll get all of them at once
    ridx = np.random.random(size=n)
    # the one loop we can't avoid, made as simple as possible
    idx = np.zeros(n, dtype=int)
    for i, r in enumerate(ridx):
        idx[i] = np.searchsorted(cdf[i], r)
    # fancy indexing all at once is faster than indexing in a loop
    return items[idx]


class LockBatch(gym.Env):
    """A (stochastic) combination lock environment.
    
    Can configure the length, dimension, and switching probability via env_config"""

    def __init__(self,env_config={}):
        self.initialized=False
        
    def init(self,horizon=100, action_dim=10, p_switch=0.5, p_anti_r=0.5, anti_r=0.1,noise=0.1, num_envs=10, temperature=1, 
                variable_latent=False, dense=False, L=2):
        self.seed=0 #added by Jiacheng
        
        self.initialized=True
        self.max_reward=1
        self.horizon=horizon
        self.state_dim = 3
        self.action_dim = action_dim
        self.action_space = Discrete(self.action_dim)
        self.history=[]#Jiacheng added, list that records all jobs given
        self.num_interact = 0 # number of times actions getting in
        self.L = L # Jiacheng's added
        self.reward_range = (0.0,1.0)

        self.observation_dim = 2 ** int(math.ceil(np.log2(self.horizon+4)))
        self.z_dim=2**self.observation_dim
        #self.observation_dim = 2
        self.z_space = Box(low=0.0, high=1.0, shape=(self.z_dim,),dtype=np.float)

        self.observation_space = Box(low=0.0, high=1.0, shape=(self.observation_dim,),dtype=np.float)

        self.p_switch = p_switch
        self.p_anti_r = p_anti_r
        self.anti_r = anti_r
        self.noise = noise
        self.rotation = scipy.linalg.hadamard(self.observation_space.shape[0])

        self.num_envs = num_envs
        self.tau = temperature

        self.variable_latent = variable_latent
        self.dense = dense

        self.optimal_reward = 1
        if dense:
            self.step_reward = 0.1

        self.all_latents = np.arange(self.state_dim)

        self.opt_a = np.random.randint(low=0, high=self.action_space.n, size=self.horizon)
        self.opt_b = np.random.randint(low=0, high=self.action_space.n, size=self.horizon)

        print("[LOCK] Initializing Combination Lock Environment")
        print("[LOCK] A sequence: ", end="")
        print([z for z in self.opt_a])
        print("[LOCK] B sequence: ", end="")
        print([z for z in self.opt_b])

    def step(self,action):
        if self.h == self.horizon:
            raise Exception("[LOCK] Exceeded horizon")

        r = np.zeros((self.num_envs,1))
        next_state = np.zeros(self.num_envs, dtype=np.int)
        ber = np.random.binomial(1, self.p_switch, self.num_envs)
        ber_r = np.random.binomial(1, self.p_anti_r, self.num_envs)
        ## First check for end of episode
        if self.h == self.horizon-1:
            ## Done with episode, need to compute reward
            for e in range(self.num_envs):
                if self.state[e] == 0 and action[e] == self.opt_a[self.h]:
                    r[e] = self.optimal_reward
                    if ber[e]:
                        next_state[e] = 1
                    else:
                        next_state[e] = 0
                elif self.state[e] == 1 and action[e] == self.opt_b[self.h]:
                    r[e] = self.optimal_reward
                    if ber[e]:
                        next_state[e] = 1
                    else:
                        next_state[e] = 0
                else:
                    if self.state[e] != 2 and ber_r[e]:
                        if not self.dense:
                            r[e] = self.anti_r
                    next_state[e] = 2
            self.h +=1
            self.state = next_state
            obs = self.make_obs(self.state)
            
            if self.variable_latent:
                self.sample_latent(obs)
            self.history.append(obs)
            self.num_interact += 1
            self.history[self.num_interact - 1:self.num_interact]
            z=self.history
            return z, r, True, {}

        
        ## Decode current state
        for e in range(self.num_envs):
            if self.state[e] == 0:
                ## In state A
                if action[e] == self.opt_a[self.h]:
                    if self.dense:
                        r[e] = self.step_reward
                    if ber[e]:
                        next_state[e] = 1
                    else:
                        next_state[e] = 0
                else:
                    if ber_r[e]:
                        if not self.dense:
                            r[e] = self.anti_r
                    next_state[e] = 2
            elif self.state[e] == 1:
                ## In state B
                if action[e] == self.opt_b[self.h]:
                    if self.dense:
                        r[e] = self.step_reward
                    if ber[e]:
                        next_state[e] = 0
                    else:
                        next_state[e] = 1
                else:
                    if ber_r[e] and not self.dense:
                        r[e] = self.anti_r
                    next_state[e] = 2
            else:
                ## In state C
                next_state[e] = 2
            if self.state[e] == 0:
                ## In state a
                if action[e] == self.opt_a[self.h]:
                    if self.dense:
                        r[e] = self.step_reward
                    if ber[e]:
                        next_state[e] = 4
                    else:
                        next_state[e] = 3
                else:
                    if ber_r[e]:
                        if not self.dense:
                            r[e] = self.anti_r
                    next_state[e] = 5
            elif self.state[e] == 4:
                ## In state b
                if action[e] == self.opt_b[self.h]:
                    if self.dense:
                        r[e] = self.step_reward
                    if ber[e]:
                        next_state[e] = 3
                    else:
                        next_state[e] = 4
                else:
                    if ber_r[e] and not self.dense:
                        r[e] = self.anti_r
                    next_state[e] = 5
            else:
                ## In state c
                next_state[e] = 5
        self.h +=1
        self.state = next_state
        obs = self.make_obs(self.state)
        if self.variable_latent:
            self.sample_latent(obs)
        #self.history.append(obs)
        self.num_interact += 1
        z = self.create_z_matrix(obs, self.prev_obs)
        self.prev_obs = obs
        #self.history[self.num_interact - 1:self.num_interact]
        #z=self.history
        return z, r, False, {}
    
    def get_state(self):
        return self.state

    def get_counts(self):
        counts = np.zeros(3, dtype=np.int)
        for i in range(self.num_envs):
            counts[self.state[i]] += 1

        return counts
    def create_z_matrix(self, obs, prev_obs):
        if prev_obs is None:
            prev_obs = np.zeros_like(obs)
        print(obs.shape,prev_obs.shape)
        return np.concatenate((prev_obs, obs), axis=1)
        
    def make_obs(self, s):

        gaussian = np.zeros((self.num_envs, self.observation_space.shape[0]))
        gaussian[:,:(self.horizon+self.state_dim)] = np.random.normal(0,self.noise,[self.num_envs,self.horizon+self.state_dim])
        #gaussian[:,:2] = np.random.uniform(0, self.noise, [self.num_envs, 2])#Jiacheng added
        gaussian[np.arange(self.num_envs), s] += 1
        gaussian[:,self.state_dim+self.h] += 1
        x = np.matmul(self.rotation, gaussian.T).T
        #if self.h % 2 == 1:  # if odd
            #np.concatenate([x, np.zeros(self.observation_dim,self.observation_dim)],axis = 1)
        self.latents = gaussian[:,:3]

        

        return x

    def sample_latent(self, obs):
        
        latent_exp = np.exp(self.latents / self.tau)

        softmax = latent_exp / latent_exp.sum(axis=-1, keepdims=True)
        self.state = sample(softmax, self.all_latents, self.num_envs)

    def generate_obs(self, s, h):

        gaussian = np.zeros((self.num_envs, self.observation_space.shape[0]))
        gaussian[:,:(self.horizon+self.state_dim)] = np.random.uniform(0,self.noise,[self.num_envs,self.horizon+self.state_dim])
        #gaussian[:,:2] = np.random.uniform(0, self.noise, [self.num_envs, 2])#Jiacheng added
        gaussian[:, s] += 1
        gaussian[:,self.state_dim+h] += 1

        x = np.matmul(self.rotation, gaussian.T).T

        return x

    def trim_observation(self,o,h):
        return (o)
    def reset(self, bad=False):
        if not self.initialized:
            raise Exception("Environment not initialized")
        self.h=0

        self.state = np.random.binomial(1, self.p_switch, self.num_envs)

        if bad:
            self.state = np.zeros(self.num_envs, dtype=np.int)
            for i in range(self.num_envs):
                if np.random.rand() > 0.1:
                    self.state[i] = 2
                else:
                    self.state[i] = np.random.binomial(1, self.p_switch, 1)[0]
            self.h = 1
        self.prev_obs = None  # Initialize prev_obs as None
        obs = self.make_obs(self.state)
        z = self.create_z_matrix(obs, self.prev_obs)

        self.prev_obs = obs  # Initialize prev_obs

        return (z)
    

    def render(self,mode='human'):
        if self.state == 0:
            print("A%d" % (self.h))
        if self.state == 1:
            print("B%d" % (self.h))
        if self.state == 2:
            print("C%d" % (self.h))
        

# 将此处的代码粘贴到LockBatch类的代码中，作为新的方法
def make_pomdp_obs(self, s, h, M):
    observation_dim = 2 * M + 3 if h % 2 == 0 else 2 * M
    gaussian = np.zeros((self.num_envs, observation_dim))

    gaussian[:, :3] = np.random.uniform(0, self.noise, [self.num_envs, 3])
    gaussian[np.arange(self.num_envs), s] += 1
    gaussian[:, 3 + h] += 1

    o1, o2, o3 = np.zeros((self.num_envs, self.observation_dim)), np.zeros((self.num_envs, self.observation_dim)), np.zeros((self.num_envs, self.observation_dim))
    o1[:, :observation_dim], o2[:, :observation_dim], o3[:, :observation_dim] = gaussian, gaussian, gaussian
    o1[:, observation_dim:], o2[:, observation_dim:], o3[:, observation_dim:] = gaussian[:, :self.observation_dim - observation_dim], gaussian[:, :self.observation_dim - observation_dim], gaussian[:, :self.observation_dim - observation_dim]

    x1, x2, x3 = np.matmul(self.rotation, o1.T).T, np.matmul(self.rotation, o2.T).T, np.matmul(self.rotation, o3.T).T

    return x1, x2, x3

# 将此处的代码粘贴到LockBatch类的代码中，替换原始的make_obs方法
def make_obs(self, s, h, M):
    if h % 2 == 0:
        o1, o2, o3 = self.make_pomdp_obs(s, h, M)
        p_o1, p_o2, p_o3 = 1 / (M + 1), 1 / (M + 1), 1 / (M + 1)
        p_o_rest = M / (M + 1)
        prob_matrix = np.zeros((self.num_envs, 3))
        prob_matrix[:, 0], prob_matrix[:, 1], prob_matrix[:, 2] = p_o1, p_o2, p_o3
        selected_indices = sample(prob_matrix, np.arange(3), self.num_envs)
        obs = np.where(selected_indices[:, None] == 0, o1, np.where(selected_indices[:, None] == 1, o2, o3))
    else:
        obs = self.make_pomdp_obs(s, h, M)[0]

    return obs



class LockBatch(gym.Env):
    # ... 其他代码 ...

    def make_pomdp_obs(self, s, h, M):
        # ... 与之前相同 ...

    def make_obs(self, s, h, M):
        # ... 与之前相同 ...

class ExtendedPOMDP(LockBatch):
    def __init__(self, pomdp):
        super().__init__(pomdp.num_envs, pomdp.M)
        self.pomdp = pomdp
        self.prev_observation = np.zeros_like(self.pomdp.reset())

    def reset(self):
        self.prev_observation = np.zeros_like(self.pomdp.reset())
        return self.get_concatenated_observation()

    def step(self, action):
        observation, reward, done, info = self.pomdp.step(action)
        concatenated_observation = self.get_concatenated_observation(observation)
        self.prev_observation = observation
        return concatenated_observation, reward, done, info

    def get_concatenated_observation(self, observation=None):
        if observation is None:
            observation = self.pomdp.observe()
        z = np.concatenate((self.prev_observation, observation), axis=None)  # 这里创建了变量 z
        return z

    def __getattr__(self, attr):
        return getattr(self.pomdp, attr)

def concatenate_pomdps(pomdp1, pomdp2):
    return ExtendedPOMDP(pomdp1), ExtendedPOMDP(pomdp2)



class ConcatenatedPOMDP(gym.Env):
    def __init__(self, H, M, noise=0.1):
        super().__init__()

        self.H = H
        self.M = M
        self.noise = noise

        self.action_space = spaces.Discrete(10)
        self.observation_space = spaces.Box(low=0, high=1, shape=(2**int(np.ceil(np.log2(H+4))),))

        self.state_space_a = ["a", "b", "c"]
        self.state_space_b = ["A", "B", "C"]

        self.special_actions_a = np.random.randint(0, 10, size=(H, 2))
        self.special_actions_b = np.random.randint(0, 10, size=(H, 2))

        self.hadamard_matrix = self.generate_hadamard_matrix(2**int(np.ceil(np.log2(H+4))))

    def generate_hadamard_matrix(self, n):
        H = np.array([[1]])
        for i in range(int(np.log2(n))):
            H = np.vstack((np.hstack((H, H)), np.hstack((H, -H))))
        return H

    def reset(self):
        self.h = 0
        if np.random.random() < 0.5:
            self.current_state_a = "a"
        else:
            self.current_state_a = "b"

        if np.random.random() < 0.5:
            self.current_state_b = "A"
        else:
            self.current_state_b = "B"

        return self.observe()

    def step(self, action):  # action, state -> obs
        reward = 0
        done = self.h == self.H - 1

        if self.h % 2 == 0:  # Even horizon
            state_changed_a = False
            state_changed_b = False

            if self.current_state_a in ["a", "b"]:
                if action == self.special_actions_a[self.h, 0 if self.current_state_a == "a" else 1]:
                    self.current_state_a = np.random.choice(["a", "b"])
                    state_changed_a = True
                else:
                    self.current_state_a = "c"

            if self.current_state_b in ["A", "B"]:
                if action == self.special_actions_b[self.h, 0 if self.current_state_b == "A" else 1]:
                    self.current_state_b = np.random.choice(["A", "B"])
                    state_changed_b = True
                else:
                    self.current_state_b = "C"

            if not state_changed_a and self.current_state_a in ["a", "b"]:
                reward -= 0.1

            if not state_changed_b and self.current_state_b in ["A", "B"]:
                reward -= 0.1

        else:  # Odd horizon
            if self.current_state_a != "c":
                if action == self.special_actions_a[self.h, 0 if self.current_state_a == "a" else 1]:
                    self.current_state_a = np.random.choice(["a", "b"])
                else:
                    self.current_state_a = "c"

            if self.current_state_b != "C":
                if action == self.special_actions_b[self.h, 0 if self.current_state_b == "A" else 1]:
                    self.current_state_b = np.random.choice(["A", "B"])
                else:
                    self.current_state_b




