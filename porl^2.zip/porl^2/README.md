## Prerequisites

Creating a virtual environment is recommended (or using conda alternatively):
```bash
pip install virtualenv
virtualenv /path/to/venv --python=python3

#To activate a virtualenv: 

. /path/to/venv/bin/activate
```



To install pytorch, please follow [PyTorch](http://pytorch.org/). Note that the current implementation does not require pytorch gpu.

We use [wandb](https://wandb.ai/home) to perform result collection, please setup wandb before running the code or add `os.environ['WANDB_MODE'] = 'offline'` in `main.py`.




To see all the hyperparameters, please refer to `utils.py`.


