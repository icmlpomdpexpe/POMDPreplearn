import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import copy
import math

from algs.base_learner import kron, weight_init, Feature, Discriminator, BaseLearner
from utils import parse_args, set_seed_everywhere, ReplayBuffer, make_batch_env
def kron(a, b):
    siz1 = torch.Size(torch.tensor(a.shape[-1:]) * torch.tensor(b.shape[-1:]))
    res = a.unsqueeze(-1) * b.unsqueeze(-2)
    siz0 = res.shape[:-2]
    return res.reshape(siz0 + siz1)
class YourNeuralNetworkModel(nn.Module):
    def __init__(self, z_dim, action_dim, device, state_dim=6, tau=1, softmax="vanilla"):
        super(YourNeuralNetworkModel, self).__init__()

        self.feature = Feature(z_dim, action_dim, device, state_dim=state_dim, tau=tau, softmax=softmax)
        
    #def forward(self, z, action):
        #return self.feature(z, action)

class Feature(nn.Module):
    def __init__(self, z_dim, action_dim, device, state_dim=6, tau=1, softmax="vanilla"):
        super().__init__()

        self.device = device
        self.z_dim = z_dim
        self.action_dim = action_dim
        self.state_dim = state_dim

        self.tau = tau
        self.softmax = softmax

        self.encoder = nn.Linear(z_dim, state_dim, bias=False)
        self.weights = nn.Linear(state_dim * action_dim, 1, bias=False)

        self.apply(weight_init)
    
    def forward(self, z, action):
        

        #assert z.size(0) == action.size(0)
        state_encoding = self.encoder(z)
        if self.softmax == "gumble":
            state_encoding = F.gumbel_softmax(state_encoding, tau=self.tau, hard=False)
        elif self.softmax == 'vanilla': 
            state_encoding = F.softmax(state_encoding / self.tau, dim=-1)
        phi = kron(action, state_encoding)

        return phi
    
    def weight_init(m):
        if isinstance(m, nn.Linear):
            nn.init.orthogonal_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)
        elif isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
            m.weight.data.fill_(0.0)
            m.bias.data.fill_(0.0)
            mid = m.weight.size(2) // 2
            gain = nn.init.calculate_gain('relu')
            nn.init.orthogonal_(m.weight.data[:, :, mid, mid], gain)


class YourNeuralNetworkModelmu(nn.Module):
    def __init__(self, z_dim, device, state_dim=6, tau=1, softmax="vanilla"):
        super(YourNeuralNetworkModelmu, self).__init__()

        self.featuremu = Featuremu(z_dim, device, state_dim=state_dim, tau=tau, softmax=softmax)
        
   

class Featuremu(nn.Module):
    def __init__(self, z_dim, device, state_dim=6, tau=1, softmax="vanilla"):
        super().__init__()

        self.device = device
        self.z_dim = z_dim
        self.state_dim = state_dim
        
        self.tau = tau
        self.softmax = softmax
        
        self.encodermu = nn.Linear(z_dim, 60, bias=False)

        self.apply(weight_init)
    
    def forward(self, z):
        state_encodingmu = self.encodermu(z)
        if self.softmax == "gumble":
            state_encodingmu = F.gumbel_softmax(state_encodingmu, tau=self.tau, hard=False)
        elif self.softmax == 'vanilla': 
            state_encodingmu = F.softmax(state_encodingmu / self.tau, dim=-1)
        mu = state_encodingmu/2

        return mu
    
    def weight_initmu(m):
        if isinstance(m, nn.Linear):
            nn.init.orthogonal_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)
        elif isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
            m.weight.data.fill_(0.0)
            m.bias.data.fill_(0.0)
            mid = m.weight.size(2) // 2
            gain = nn.init.calculate_gain('relu')
            nn.init.orthogonal_(m.weight.data[:, :, mid, mid], gain)
class RepLearn:
    def __init__(self,  z_dim, action_dim, device, state_dim=6, tau=1, softmax="vanilla"):
        
        self.phi_models = [YourNeuralNetworkModel(z_dim, action_dim, device, state_dim, tau, softmax)]
        self.mu_models = [YourNeuralNetworkModelmu(z_dim, device, state_dim, tau, softmax)]
        self.num_feature_update = 1000
        self.device = device
        self.batch_size=128
        self.phi = Feature(z_dim, action_dim, device, tau=tau, softmax=softmax).to(device)
        self.mu = Featuremu(z_dim, device, tau=tau, softmax=softmax).to(device)
    def learn_representation(self, buffers, lr=1e-3):
        optimizer_phi = [torch.optim.Adam(phi.parameters(), lr=lr) for phi in self.phi_models]
        optimizer_mu = [torch.optim.Adam(mu.parameters(), lr=lr) for mu in self.mu_models]
        
        for i in range(self.num_feature_update):
            zs, actions, rewards, next_zs = buffers.sample(batch_size=self.batch_size)
            max_expectation = -np.inf
            best_phi_idx, best_mu_idx = None, None
        

                

            for i, phi in enumerate(self.phi_models):
                for j, mu in enumerate(self.mu_models):
                    phi_out = phi(zs, actions)
                    mu_out = mu(next_zs)

                    expectation = torch.mean(torch.log(torch.matmul(phi_out, mu_out.t())))
                    if expectation > max_expectation:
                        max_expectation = expectation
                        best_phi_idx, best_mu_idx = i, j

            best_phi = self.phi_models[best_phi_idx]
            best_mu = self.mu_models[best_mu_idx]

            phi_loss = -torch.mean(torch.log(torch.matmul(best_phi(zs, actions), best_mu(next_zs, actions).t())))
            mu_loss = -torch.mean(torch.log(torch.matmul(best_phi(zs, actions), best_mu(next_zs, actions).t())))

            optimizer_phi[best_phi_idx].zero_grad()
            phi_loss.backward(retain_graph=True)
            optimizer_phi[best_phi_idx].step()

            optimizer_mu[best_mu_idx].zero_grad()
            mu_loss.backward()
            optimizer_mu[best_mu_idx].step()
        